# Calendar App
# Tasks

## 1. You can create index.php using index.html
## 2. When you open the index.php, in the top area of calendar, current month and current year should be shown and today's date should be highlited like index.html
## 3. If you click the left arrow button the previous month calendar should be shown.
## 4. If you click the right arrow button the next month calendar should be shown.